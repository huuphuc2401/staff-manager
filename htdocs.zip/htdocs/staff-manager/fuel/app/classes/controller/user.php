<?php

class Controller_User extends Controller_Hybrid {

	protected $format = 'json';

	public function get_index() {
		return $this->response(Model_User::find('all'));
	}

	public function post_index() {
		$user = Model_User::forge(array(
			'username' => Input::json('username'),
			'password' => Input::json('password'),
			'email' => Input::json('email'),
		));

		$user->save();
		return $this->response(array('result' => 'success'));
	}

}
