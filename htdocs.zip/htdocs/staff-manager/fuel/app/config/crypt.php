<?php
return array (
  'crypto_key' => 'urwH0ko_s1acfnA0OAwS4guY',
  'crypto_iv' => 'g6EhpIjF4qtgtAk1dQkGE1gI',
  'crypto_hmac' => 'ul4de46U0_4ct6Iwgkjho9sM',
);
