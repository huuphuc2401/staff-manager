<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2017-03-22 16:30:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-03-22 16:30:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
