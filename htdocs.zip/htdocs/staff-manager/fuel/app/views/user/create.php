<h2>New <span class='muted'>User</span></h2>
<br>

<?php echo render('user/_form'); ?>


<p><?php echo Html::anchor('user', 'Back'); ?></p>
