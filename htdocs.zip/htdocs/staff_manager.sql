-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2017 at 06:53 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `staff_manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `type` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `migration` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`type`, `name`, `migration`) VALUES
('app', 'default', '001_create_users');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `created_at`, `updated_at`) VALUES
(1, 'phuc', 'xtrans', 'phuc@example.com', 1490108735, 1490108735),
(2, 'gau', 'xtrans', '', 1490108751, 1490108751),
(4, 'John', '2pm', '', 1490717116, 1490717116),
(5, 'test01', 'xtrans', 'test01@example.com', 1490719208, 1490719208),
(6, 'test01', 'xtrans', 'test01@example.com', 1490719220, 1490719220),
(7, 'test02', '123456', 'test02@example.com', 1490719303, 1490719303),
(8, 'ssfdsf', 'dfsdf', 'fsdfsdf', 1490719357, 1490719357),
(9, 'ssfdsf', 'dfsdf', 'fsdfsdf', 1490719432, 1490719432),
(10, 'rrrrrr', 'rrrrrrrr', 'rrrrrrrrrr', 1490719480, 1490719480),
(11, 'gggggggg', 'gggggggg', 'ggggggggggg', 1490719494, 1490719494),
(12, 'rrrrrrrrr', 'rrrggggggggg', 'ggggggggggggg', 1490719510, 1490719510),
(13, 'gggggggggggggggg', 'ggggggggggggd', 'gdddddddddddddd', 1490719516, 1490719516),
(14, 'fds', 'fsdsf', 'fsfsff', 1490719527, 1490719527),
(15, 'aaa', 'ddd', 'ggg', 1490719783, 1490719783);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
