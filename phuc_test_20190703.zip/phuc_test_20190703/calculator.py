import re
from calculator_errors import ExpressionFormatError
class Calculator:
    expression = ''
    errorMessage = ''

    def calculate(self):
        try:
            if re.match('^([0-9]|\+|\-|\*|\/|\.|\(|\)|\s)*$', self.expression) == None:
                raise ExpressionFormatError

            return eval(self.expression)

        except ExpressionFormatError:
            self.errorMessage = 'Error: expression format error'
            return None
        except ZeroDivisionError:
            self.errorMessage = 'Error: division by zero'
            return None
        except SyntaxError:
            self.errorMessage = 'Error: calculation error'
            return None

    def getError(self):
        return self.errorMessage

    def __init__(self, expression = ''):
        self.expression = expression
