class ExpressionFormatError(Exception):
    pass


