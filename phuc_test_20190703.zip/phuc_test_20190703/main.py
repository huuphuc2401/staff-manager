from calculator import Calculator
from robot import Robot

# help
print('---- Welcome to Phuc\'s calculator')
print('---- You can input an expression to calculate (Example: 1 + 2) and press enter')
print('---- Expression only accept number 0-9, +, -, *, /, ., (, ) and space')
print('---- You can calculate with the previous result. Example: 1 + 2 = 3 + 4 = 7')
print('---- Press enter to clear previous result')
print('---- Type "quit" then press enter to exit the program')
print('---- * Secret feature: Type "robot" then press enter to call a robot')
print('Please input an expression:')

previousResult = ''
while True:
    try:
        inputString = input()
    except: # catch error when force break program (Ex: Ctrl + Z)
        print('bye bye')
        break

    # extend feature
    if inputString == 'robot':
        previousResult = ''
        robot = Robot()
        robot.kill()
        continue

    if inputString == 'quit':
        print('bye bye')
        break

    if inputString == '':
        previousResult = ''
        continue

    cal = Calculator(previousResult + inputString)
    result = cal.calculate()

    if result == None:
        print(cal.getError())
        previousResult = ''
        continue

    previousResult = str(result) + ' '
    print('=', result, end='')
