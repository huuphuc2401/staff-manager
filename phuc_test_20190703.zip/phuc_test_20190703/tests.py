import unittest
from calculator import Calculator 

class TestCalculator(unittest.TestCase):

    def test_expression_format_error(self):
        calc = Calculator(expression='invalid')
        self.assertEqual(calc.calculate(), None)
        self.assertEqual(calc.getError(), 'Error: expression format error')

    def test_division_by_zero(self):
        calc = Calculator(expression='5 / 0')
        self.assertEqual(calc.calculate(), None)
        self.assertEqual(calc.getError(), 'Error: division by zero')

    def test_calculation_error(self):
        calc = Calculator(expression='5 +')
        self.assertEqual(calc.calculate(), None)
        self.assertEqual(calc.getError(), 'Error: calculation error')

    def test_calculate_integer(self):
        calc = Calculator(expression='5 + 7')
        self.assertEqual(calc.calculate(), 12)
        self.assertEqual(calc.getError(), '')

    def test_calculate_float(self):
        calc = Calculator(expression='10.5 + 11.6')
        self.assertEqual(calc.calculate(), 22.1)
        self.assertEqual(calc.getError(), '')

    def test_plus(self):
        calc = Calculator(expression='1 + 2')
        self.assertEqual(calc.calculate(), 3)
        self.assertEqual(calc.getError(), '')

    def test_subtract(self):
        calc = Calculator(expression='1 - 2')
        self.assertEqual(calc.calculate(), -1)
        self.assertEqual(calc.getError(), '')

    def test_multiple(self):
        calc = Calculator(expression='12 * 5')
        self.assertEqual(calc.calculate(), 60)
        self.assertEqual(calc.getError(), '')

    def test_divide(self):
        calc = Calculator(expression='120 / 5')
        self.assertEqual(calc.calculate(), 24)
        self.assertEqual(calc.getError(), '')

if __name__ == '__main__':
    unittest.main()